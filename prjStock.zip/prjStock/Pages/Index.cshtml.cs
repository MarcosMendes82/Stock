﻿using System;
using System.Web;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using Microsoft.AspNetCore.Mvc.RazorPages;
using prjStock.Performance.Models;
using prjStock.Performance.Controllers;

namespace prjStock.Pages
{
    public class IndexModel : PageModel
    {
        
    }
}
